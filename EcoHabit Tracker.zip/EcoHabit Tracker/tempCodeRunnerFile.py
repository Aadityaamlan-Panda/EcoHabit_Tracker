import tkinter as tk
from tkinter import messagebox
import requests
import time
import psutil
import matplotlib.pyplot as plt
import threading

# Open Hardware Monitor URL
url = "http://localhost:8085/data.json"

# Carbon Emission Factor
EMISSION_FACTOR = 0.5  # in kg CO2/kWh
NETWORK_EMISSION_FACTOR = 0.02  # in kg CO2/GB

# Global lists to store data for plotting
timestamps = []
cpu_powers = []
gpu_powers = []
carbon_footprints = []
cumulative_carbon_footprints = []  # New: To store cumulative carbon footprint
network_sent = []
network_received = []
app_carbon_footprints = {}  # New: To store carbon footprints per app

def fetch_hardware_data():
    """Fetch hardware data from Open Hardware Monitor via HTTP API"""
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        if "Children" in data:
            return data
        else:
            print("Error: 'Children' key not found in data")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from Open Hardware Monitor: {e}")
        return None

def extract_power_data(data):
    """Extract power consumption data from Open Hardware Monitor JSON response."""
    def parse_sensor(sensor, power_data):
        if 'Children' in sensor:
            for child in sensor['Children']:
                if child.get('Text') == "CPU Package":
                    try:
                        power_data['CPU_Power'] = float(child['Value'].split()[0])
                    except (ValueError, IndexError):
                        pass
                elif child.get('Text') == "GPU Power":
                    try:
                        power_data['GPU_Power'] = float(child['Value'].split()[0])
                    except (ValueError, IndexError):
                        pass
                parse_sensor(child, power_data)

    if not data or 'Children' not in data:
        return None

    power_data = {}
    for sensor in data['Children']:
        parse_sensor(sensor, power_data)

    return power_data if power_data else None

def calculate_carbon_footprint(power_data, time_elapsed_seconds):
    """Calculate the carbon footprint from power consumption."""
    if not power_data:
        return None

    cpu_power_kWh = power_data.get('CPU_Power', 0) / 1000
    gpu_power_kWh = power_data.get('GPU_Power', 0) / 1000
    total_power_kWh = cpu_power_kWh + gpu_power_kWh
    carbon_footprint = total_power_kWh * EMISSION_FACTOR * (time_elapsed_seconds / 3600)  # Convert seconds to hours
    return carbon_footprint

def fetch_network_usage():
    """Fetch network usage and calculate its carbon footprint."""
    try:
        net_io = psutil.net_io_counters()
        sent = net_io.bytes_sent
        received = net_io.bytes_recv

        sent_gb = sent / (1024**3)
        received_gb = received / (1024**3)
        network_carbon_footprint = (sent_gb + received_gb) * NETWORK_EMISSION_FACTOR

        return sent, received, network_carbon_footprint
    except Exception as e:
        print(f"Error fetching network data: {e}")
        return 0, 0, 0

def calculate_app_carbon_footprint(cpu_power, time_elapsed_seconds):
    """Calculate carbon footprint per application based on CPU usage."""
    global app_carbon_footprints

    try:
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent']):
            cpu_usage = proc.info['cpu_percent'] / psutil.cpu_count()
            app_carbon = (cpu_power * (cpu_usage / 100)) * EMISSION_FACTOR * (time_elapsed_seconds / 3600)
            app_name = proc.info['name']

            if app_name in app_carbon_footprints:
                app_carbon_footprints[app_name] += app_carbon
            else:
                app_carbon_footprints[app_name] = app_carbon

    except Exception as e:
        print(f"Error calculating app-specific carbon footprint: {e}")

def log_data(power_data, carbon_footprint, cumulative_footprint, sent, received, network_carbon_footprint):
    """Log data to a file."""
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open("power_and_carbon_log.csv", mode='a') as file:
        file.write(f"{timestamp},{power_data.get('CPU_Power', 'N/A')},{power_data.get('GPU_Power', 'N/A')},{carbon_footprint},{cumulative_footprint},{sent},{received},{network_carbon_footprint}\n")


def show_all_app_carbon_footprints():
    """Display all apps with their carbon footprint in descending order."""
    if app_carbon_footprints:
        # Sort the apps by their carbon footprints in descending order
        sorted_apps = sorted(app_carbon_footprints.items(), key=lambda x: x[1], reverse=True)

        # Create a readable string with app names and carbon footprints
        app_details = "\n".join([f"{app}: {footprint * 1000:.4f} g CO2" for app, footprint in sorted_apps])

        # Display the details in a message box
        messagebox.showinfo("Carbon Footprint by Apps", f"Carbon Footprint (Descending Order):\n\n{app_details}")
    else:
        messagebox.showinfo("Carbon Footprint by Apps", "No data available.")



def show_most_carbon_intensive_app():
    """Identify and display the app with the highest carbon footprint."""
    if app_carbon_footprints:
        most_intensive_app = max(app_carbon_footprints, key=app_carbon_footprints.get)
        carbon = app_carbon_footprints[most_intensive_app]*1000
        messagebox.showinfo("Most Carbon-Intensive App", f"{most_intensive_app} consumed the most carbon: {carbon:.4f} g CO2")
    else:
        messagebox.showinfo("Most Carbon-Intensive App", "No data available.")
        
monitoring_active = True  # Will be set to False when quitting

def quit_application():
    """Stop monitoring and exit the application."""
    global monitoring_active
    monitoring_active = False  # Stop the monitoring thread
    root.destroy()  # Close the Tkinter window and exit

def plot_data():
    """Plot the data, including cumulative carbon footprint with a better appearance."""
    plt.figure(figsize=(16, 12))  # Increase the figure size for better spacing

    # Define the interval for x-axis labels
    interval = max(1, len(timestamps) // 10)  # Show 10 evenly spaced labels at most
    tick_indices = range(0, len(timestamps), interval)
    tick_labels = [timestamps[i] for i in tick_indices]

    # Subplot 1: Power Consumption
    plt.subplot(2, 2, 1)
    plt.plot(cpu_powers, label='CPU Power (W)', color='#1f77b4', linewidth=2)
    plt.plot(gpu_powers, label='GPU Power (W)', color='#ff7f0e', linewidth=2)
    plt.xticks(tick_indices, tick_labels, rotation=45, ha='right', fontsize=10)
    plt.xlabel('Time', fontsize=12)
    plt.ylabel('Power (W)', fontsize=12)
    plt.title('Power Consumption', fontsize=14)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', linewidth=0.5)

    # Subplot 2: Incremental Carbon Footprint
    plt.subplot(2, 2, 2)
    plt.plot(carbon_footprints, label='Incremental Carbon Footprint (kg CO2)', color='#2ca02c', linewidth=2)
    plt.xticks(tick_indices, tick_labels, rotation=45, ha='right', fontsize=10)
    plt.xlabel('Time', fontsize=12)
    plt.ylabel('Carbon Footprint (kg CO2)', fontsize=12)
    plt.title('Incremental Carbon Footprint', fontsize=14)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', linewidth=0.5)

    # Subplot 3: Network Usage
    plt.subplot(2, 2, 3)
    plt.plot(network_sent, label='Bytes Sent', color='#9467bd', linewidth=2)
    plt.plot(network_received, label='Bytes Received', color='#8c564b', linewidth=2)
    plt.xticks(tick_indices, tick_labels, rotation=45, ha='right', fontsize=10)
    plt.xlabel('Time', fontsize=12)
    plt.ylabel('Network Usage (Bytes)', fontsize=12)
    plt.title('Network Usage', fontsize=14)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', linewidth=0.5)

    # Subplot 4: Cumulative Carbon Footprint
    plt.subplot(2, 2, 4)
    plt.plot(cumulative_carbon_footprints, label='Cumulative Carbon Footprint (kg CO2)', color='#d62728', linewidth=2)
    plt.xticks(tick_indices, tick_labels, rotation=45, ha='right', fontsize=10)
    plt.xlabel('Time', fontsize=12)
    plt.ylabel('Cumulative Carbon Footprint (kg CO2)', fontsize=12)
    plt.title('Cumulative Carbon Footprint', fontsize=14)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', linewidth=0.5)

    # Adjust layout to prevent overlap
    plt.tight_layout()  # Add padding between plots
    plt.subplots_adjust(bottom=0.15, hspace=1.0)  # Add space at the bottom for x-axis labels
    plt.show()


def start_monitoring():
    """Start monitoring based on user input."""
    try:
        max_time_minutes = int(duration_entry.get())
        if max_time_minutes <= 0:
            raise ValueError("Time must be positive.")
    except ValueError as e:
        # Display an error icon and message when input is invalid
        status_label.config(text="❌ Invalid input! Please enter a positive number of minutes.")
        messagebox.showerror("Invalid Input", "Please enter a positive number of minutes.")
        return

    max_time_seconds = max_time_minutes * 60
    start_time = time.time()
    status_label.config(text="⌛ Monitoring in progress...")
    timestamps.clear()
    cpu_powers.clear()
    gpu_powers.clear()
    carbon_footprints.clear()
    cumulative_carbon_footprints.clear()
    network_sent.clear()
    network_received.clear()
    app_carbon_footprints.clear()

    def monitor_task():
        """Monitor hardware and network usage."""
        cumulative_footprint = 0
        while True:
            elapsed_time = time.time() - start_time
            remaining_time = max(0, max_time_seconds - elapsed_time)

            if elapsed_time >= max_time_seconds:
                status_label.config(text="✅ Monitoring complete! Click 'Show Graph' to view results.")
                return

            status_label.config(text=f"⌛ Time remaining: {int(remaining_time // 60)} min {int(remaining_time % 60)} sec")
            data = fetch_hardware_data()
            if data:
                power_data = extract_power_data(data)
                if power_data:
                    carbon_footprint = calculate_carbon_footprint(power_data, 1)  # 5 seconds sampling
                    cumulative_footprint += carbon_footprint
                    sent, received, network_carbon_footprint = fetch_network_usage()
                    calculate_app_carbon_footprint(power_data.get('CPU_Power', 0)/1000, 1)
                    log_data(power_data, carbon_footprint, cumulative_footprint, sent, received, network_carbon_footprint)
                    timestamps.append(time.strftime("%Y-%m-%d %H:%M:%S"))
                    cpu_powers.append(power_data.get('CPU_Power', 0))
                    gpu_powers.append(power_data.get('GPU_Power', 0))
                    carbon_footprints.append(carbon_footprint)
                    cumulative_carbon_footprints.append(cumulative_footprint)
                    network_sent.append(sent)
                    network_received.append(received)
            time.sleep(1)

    # Start the monitoring process in a separate thread
    monitoring_thread = threading.Thread(target=monitor_task)
    monitoring_thread.daemon = True  # Daemonize thread to exit when the program closes
    monitoring_thread.start()

# Tkinter GUI
root = tk.Tk()
root.title("Real-Time Power and Carbon Footprint Monitor")

tk.Label(root, text="Enter Monitoring Duration🕒 (minutes):").pack(pady=5)
duration_entry = tk.Entry(root, width=20)
duration_entry.pack(pady=5)

start_button = tk.Button(root, text="Start Monitoring", command=start_monitoring)
start_button.pack(pady=5)

status_label = tk.Label(root, text="Status: Waiting for input...")
status_label.pack(pady=5)

graph_button = tk.Button(root, text="Show Graph", command=plot_data)
graph_button.pack(pady=5)

most_intensive_app_button = tk.Button(root, text="Most Carbon-Intensive App", command=show_most_carbon_intensive_app)
most_intensive_app_button.pack(pady=5)

all_apps_button = tk.Button(root, text="Show All Apps' Carbon Footprints", command=show_all_app_carbon_footprints)
all_apps_button.pack(pady=5)

# Quit button to stop monitoring and close the app
quit_button = tk.Button(root, text="Quit", command=quit_application, bg="red", fg="white")
quit_button.pack(pady=10)


root.mainloop()