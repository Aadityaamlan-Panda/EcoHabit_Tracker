import json
import webbrowser
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.slider import Slider
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.progressbar import ProgressBar
from random import choice

# Challenges and rewards data
CHALLENGES = [
    "Use public transport for a day.",
    "Avoid using plastic for 24 hours.",
    "Turn off appliances when not in use.",
    "Bike or walk instead of driving for short trips.",
    "Use reusable bags and bottles today."
]

# Rewards logic with stricter conditions
BADGES = {
    "Transport": "🚗 Car-Free Badge",
    "Energy": "⚡ Energy Saver Badge",
    "Plastic": "🌍 Plastic-Free Badge",
    "Net Carbon Footprint": "🌱 Green Champion Badge"
}

# File to track badges
BADGES_FILE = "badges.json"

# Screen for input sliders
class SliderScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation="vertical", padding=10, spacing=15)

        # Transport mode spinner
        layout.add_widget(Label(text="Select Transport Mode:"))
        self.transport_spinner = Spinner(
            text="Car",
            values=("Car", "Bike", "Bus", "Train"),
            size_hint=(1, None),
            height=50
        )
        layout.add_widget(self.transport_spinner)

        layout.add_widget(Label(text="Distance Travelled (km):"))
        self.distance_slider = Slider(min=0, max=500, value=0, orientation='horizontal', size_hint=(1, None), height=50)
        self.distance_label = Label(text="0 km", size_hint=(1, None), height=30)
        self.distance_slider.bind(value=self.update_distance_label)

        layout.add_widget(self.distance_slider)
        layout.add_widget(self.distance_label)

        layout.add_widget(Label(text="Energy Usage (kWh):"))
        self.energy_slider = Slider(min=0, max=100, value=0, orientation='horizontal', size_hint=(1, None), height=50)
        self.energy_label = Label(text="0 kWh", size_hint=(1, None), height=30)
        self.energy_slider.bind(value=self.update_energy_label)

        layout.add_widget(self.energy_slider)
        layout.add_widget(self.energy_label)

        layout.add_widget(Label(text="Plastic Usage (kg):"))
        self.plastic_slider = Slider(min=0, max=50, value=0, orientation='horizontal', size_hint=(1, None), height=50)
        self.plastic_label = Label(text="0 kg", size_hint=(1, None), height=30)
        self.plastic_slider.bind(value=self.update_plastic_label)

        layout.add_widget(self.plastic_slider)
        layout.add_widget(self.plastic_label)

        # Analyze button
        self.analyze_button = Button(text="Analyze Factors", size_hint=(1, None), height=50)
        self.analyze_button.bind(on_press=self.analyze_factors)
        layout.add_widget(self.analyze_button)

        # Net Carbon Footprint Label (Dynamic)
        self.net_footprint_label = Label(text="Net Carbon Footprint: 0.00 kg CO2e")
        layout.add_widget(self.net_footprint_label)

        self.add_widget(layout)

    def update_distance_label(self, instance, value):
        self.distance_label.text = f"{int(value)} km"
        self.update_net_footprint()

    def update_energy_label(self, instance, value):
        self.energy_label.text = f"{int(value)} kWh"
        self.update_net_footprint()

    def update_plastic_label(self, instance, value):
        self.plastic_label.text = f"{int(value)} kg"
        self.update_net_footprint()

    def update_net_footprint(self):
        # Get values from sliders
        distance = self.distance_slider.value
        energy = self.energy_slider.value
        plastic = self.plastic_slider.value

        # Calculate footprints
        transport_footprint = distance * 0.2 if self.transport_spinner.text == "Car" else distance * 0.1
        energy_footprint = energy * 0.5
        plastic_footprint = plastic * 6

        # Calculate net carbon footprint
        net_footprint = transport_footprint + energy_footprint + plastic_footprint
        self.net_footprint_label.text = f"Net Carbon Footprint: {net_footprint:.2f} kg CO2e"

    def analyze_factors(self, instance):
        # Get user input
        transport_mode = self.transport_spinner.text
        distance = self.distance_slider.value
        energy = self.energy_slider.value
        plastic = self.plastic_slider.value

        # Calculate footprints
        transport_footprint = distance * 0.2 if transport_mode == "Car" else distance * 0.1
        energy_footprint = energy * 0.5
        plastic_footprint = plastic * 6

        net_footprint = transport_footprint + energy_footprint + plastic_footprint

        # Navigate to analysis screen with results
        analysis_screen = self.manager.get_screen("analysis")
        analysis_screen.display_analysis(transport_footprint, energy_footprint, plastic_footprint, net_footprint)
        self.manager.current = "analysis"

# Screen for analysis and challenges
class AnalysisScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        self.analysis_label = Label(text="Analysis will be displayed here.")
        self.layout.add_widget(self.analysis_label)

        # Progress bar for gamification
        self.progress_bar = ProgressBar(max=100, value=0, size_hint=(1, None), height=30)
        self.layout.add_widget(self.progress_bar)

        # Add a back button
        self.back_button = Button(text="Back to Sliders", size_hint=(1, None), height=50)
        self.back_button.bind(on_press=self.go_to_slider_screen)
        self.layout.add_widget(self.back_button)

        self.add_widget(self.layout)

    def go_to_slider_screen(self, instance):
        self.manager.current = "slider"

    def display_analysis(self, transport_footprint, energy_footprint, plastic_footprint, net_footprint):
        # Determine the largest contributing factor
        factors = {
            "Transport": transport_footprint,
            "Energy": energy_footprint,
            "Plastic": plastic_footprint
        }
        max_factor = max(factors, key=factors.get)
        self.analysis_label.text = f"The largest contributing factor is {max_factor} with {factors[max_factor]:.2f} kg CO2e."

        # Create a Google search query based on the most contributing factor
        search_query = ""
        if max_factor == "Transport":
            search_query = "How to reduce carbon footprint from transport"
        elif max_factor == "Energy":
            search_query = "How to reduce energy consumption carbon footprint"
        elif max_factor == "Plastic":
            search_query = "How to reduce plastic consumption carbon footprint"

        # Create a clickable button for Google search
        google_search_url = f"https://www.google.com/search?q={search_query}"
        google_button = Button(text=f"Click here for tips to reduce {max_factor} footprint", size_hint=(1, None), height=50)
        google_button.bind(on_press=lambda instance: self.open_google_search(google_search_url))

        # Add Google search button below analysis results and before back button
        self.layout.add_widget(google_button)

        # Track and display badges earned
        badges_earned, badge_counts = self.get_badges(transport_footprint, energy_footprint, plastic_footprint, net_footprint)

        # Update progress bar (arbitrary value for gamification)
        self.progress_bar.value += 20
        if self.progress_bar.value > 100:
            self.progress_bar.value = 100

        # Display challenge and badges
        self.layout.clear_widgets()
        self.layout.add_widget(Label(text=f"Top contributing factor: {max_factor}"))
        self.layout.add_widget(Label(text=f"Net Carbon Footprint: {net_footprint:.2f} kg CO2e"))
        self.layout.add_widget(Label(text=f"Challenge: {choice(CHALLENGES)}"))

        # Display earned badges
        for badge in badges_earned:
            self.layout.add_widget(Label(text=f"Earned Badge: {badge}"))

        # Display badge counts (one below the other)
        self.layout.add_widget(Label(text="Badge Counts:"))
        for badge, count in badge_counts.items():
            self.layout.add_widget(Label(text=f"{badge}: {count}"))

        self.layout.add_widget(google_button)
        self.layout.add_widget(self.back_button)

    def open_google_search(self, url):
        webbrowser.open(url)

    def get_badges(self, transport_footprint, energy_footprint, plastic_footprint, net_footprint):
        badge_counts = self.load_badge_counts()
        badges_earned = []

        # Badge conditions (now using 'if' to allow multiple badges)
        if transport_footprint < 20:
            badge = BADGES["Transport"]
            badges_earned.append(badge)
            badge_counts["Transport"] += 1

        if energy_footprint < 30:
            badge = BADGES["Energy"]
            badges_earned.append(badge)
            badge_counts["Energy"] += 1

        if plastic_footprint < 3:
            badge = BADGES["Plastic"]
            badges_earned.append(badge)
            badge_counts["Plastic"] += 1

        if net_footprint < 50:
            badge = BADGES["Net Carbon Footprint"]
            badges_earned.append(badge)
            badge_counts["Net Carbon Footprint"] += 1

        # Save badge counts
        self.save_badge_counts(badge_counts)

        return badges_earned, badge_counts

    def load_badge_counts(self):
        # Load badge counts from a JSON file, return default counts if not present
        try:
            with open(BADGES_FILE, "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return {"Transport": 0, "Energy": 0, "Plastic": 0, "Net Carbon Footprint": 0}

    def save_badge_counts(self, badge_counts):
        # Save badge counts to a JSON file
        with open(BADGES_FILE, "w") as file:
            json.dump(badge_counts, file)

# Main App Class
class EcoHabitApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(SliderScreen(name="slider"))
        sm.add_widget(AnalysisScreen(name="analysis"))
        return sm

# Run the app
if __name__ == "__main__":
    EcoHabitApp().run()
